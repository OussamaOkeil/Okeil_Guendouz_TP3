/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.model;

import org.emp.gl.state.InitState;
import org.emp.gl.state.Reglable;

/**
 *
 * @author ouss
 */
public class Watch extends Reglable implements IContext{
    private Reglable state;

    public Watch() {
        state = new InitState(this);
    }
    
    @Override
    public void changeState(Reglable state) {
        this.state = state;
    }

    @Override
    public void doMode() {
        state.doMode();
    }

    @Override
    public void doIncrement() {
        state.doIncrement();
    }

    @Override
    public void doConfig() {
        state.doConfig();
    }
    
    
    
    
    
    
    
    
    
}
