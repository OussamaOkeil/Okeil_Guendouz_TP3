/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.state;

import org.emp.gl.model.IContext;

/**
 *
 * @author ouss
 */
public class HoursState extends Reglable{

    public HoursState(IContext context) {
        super();
        this.context = context;
        System.out.println("hours state");
    }    
    
    @Override
    public void doMode() {
        context.changeState(new SecondsState(context));
    }

    @Override
    public void doIncrement() {
        System.out.println("increment hours");
        service.setHeures((service.getHeures()+1)%24);
    }
}
