/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.state;

import org.emp.gl.model.IContext;

/**
 *
 * @author ouss
 */
public class InitState extends Reglable{

    public InitState(IContext context) {
        System.out.println("init state");
        this.context = context;
    }

    
    
    @Override
    public void doMode() {
        context.changeState(new SecondsState(context));
    }

    @Override
    public void doIncrement() {
    }

    
}
