/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.state;

import org.emp.gl.model.IContext;

/**
 *
 * @author ouss
 */
public class MinutesState extends Reglable{

    MinutesState(IContext context) {
        super();
        this.context = context;
        System.out.println("minutes state");
    }

    @Override
    public void doMode() {
        context.changeState(new HoursState(context));
    }

    @Override
    public void doIncrement() {
        System.out.println("increment minutes");
        service.setMinutes((service.getMinutes()+1)%60);
    }

    
}
