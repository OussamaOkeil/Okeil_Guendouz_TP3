/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.state;

import org.emp.gl.core.lookup.Lookup;
import org.emp.gl.model.IContext;
import org.emp.gl.timer.service.TimerService;

/**
 *
 * @author ouss
 */
public abstract class Reglable {
    
    protected IContext context;
    protected TimerService service;

    public Reglable() {
        service = Lookup.getInstance().getService(TimerService.class);
    }
    
    
    public abstract void doMode();
    public abstract void doIncrement();
    public void doConfig(){
        context.changeState(new InitState(context));
    }
}
