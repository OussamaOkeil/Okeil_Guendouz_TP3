/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.state;

import org.emp.gl.core.lookup.Lookup;
import org.emp.gl.model.IContext;

/**
 *
 * @author ouss
 */
public class SecondsState extends Reglable{

    public SecondsState(IContext context) {
        super();
        this.context = context;
        System.out.println("seconds state");
    }

    @Override
    public void doMode() {
        context.changeState(new MinutesState(context));
    }

    @Override
    public void doIncrement() {
        System.out.println("increment seconds");
        service.setSecondes((service.getSecondes()+1)%60);
    }

    
}
