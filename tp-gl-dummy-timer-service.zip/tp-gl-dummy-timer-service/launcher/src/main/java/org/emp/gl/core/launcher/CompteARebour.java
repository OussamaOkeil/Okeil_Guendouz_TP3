/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.emp.gl.core.launcher;

import java.beans.PropertyChangeEvent;
import org.emp.gl.core.lookup.Lookup;
import org.emp.gl.timer.service.TimerChangeListener;
import org.emp.gl.timer.service.TimerService;

/**
 *
 * @author tina
 */
public class CompteARebour implements TimerChangeListener {

    private int compteArebours;
    private static int id = 0;
    private int id_;

    public CompteARebour(int compteARebour) {
        id_ = id++;
        this.compteArebours = compteARebour ;
    }


    // cette méthode provient du PropertyChangeListener 
    // à utiliser plustard ! (Ignorer pour l'instant !
    @Override
    public void propertyChange(PropertyChangeEvent pce) {
        String prop = pce.getPropertyName();
        if (prop.equals(TimerChangeListener.SECONDE_PROP)) {
            compteArebours--;
            System.out.println("Il me reste : " + compteArebours +" ---> "+ id_);
        }

        if (compteArebours == 0) { // se désabonner du TimerService ! 
            Lookup.getInstance()
                    .getService(TimerService.class)
                    .removeTimeChangeListener(this);
        }
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void propertyChange(String propertyName, Object oldValue, Object newValue) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
